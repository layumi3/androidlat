package com.bdg.telkom.fusedlocationtes.baru;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bdg.telkom.fusedlocationtes.R;
import com.bdg.telkom.fusedlocationtes.baru.belumPakai.DataObject;
import com.bdg.telkom.fusedlocationtes.baru.belumPakai.SpinnerAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by lacorp on 7/17/2016.
 */
public class Login extends AppCompatActivity {
    private EditText mUsernameView;
    private EditText mPasswordView;
    private EditText mOrderView;
    private Spinner mSpinner;
    //An ArrayList for Spinner Items
    private ArrayList<String> orders;

    //JSON Array
    private JSONArray result;

    String username;
    String password;
    String order;

    SharedPreferences sh_Pref;
    android.content.SharedPreferences.Editor toEdit;
    private SessionManager session;

    private static final String PATH_TO_SERVER = "http://cerita-aje.esy.es/dataj.php";
    protected List<DataObject> spinnerData;
    private RequestQueue queue;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
        mUsernameView = (EditText) findViewById(R.id.txtUsername);
        mPasswordView = (EditText) findViewById(R.id.txtPassword);
        mOrderView= (EditText) findViewById(R.id.txtOrder);

        //Initializing the ArrayList
//        orders = new ArrayList<String>();

        //Initializing Spinner
//        mSpinner = (Spinner) findViewById(R.id.order_spinner);

        session = new SessionManager(getApplicationContext());
        //Adding an Item Selected Listener to our Spinner
        //As we have implemented the class Spinner.OnItemSelectedListener to this class iteself we are passing this to setOnItemSelectedListener
//        mSpinner.setOnItemSelectedListener(this);
//        getData();/**/
      /*  queue = Volley.newRequestQueue(this);
        requestJsonObject();*/

    }
/*Exceute once button login action*/
    public void invokeLogin(View view){
        username = mUsernameView.getText().toString();
        password = mPasswordView.getText().toString();
        order = mOrderView.getText().toString();

        Log.i("Input",username+" "+password);
        if (mUsernameView.getText().toString().isEmpty() || mPasswordView.getText().toString().isEmpty()){
            Toast.makeText(this, "Enter value in all field", Toast.LENGTH_SHORT).show();
        }
            sh_Pref = getSharedPreferences("Login Credential",MODE_PRIVATE);
            toEdit = sh_Pref.edit();
            toEdit.putString("Username", username);
            toEdit.putString("Password", password);
            toEdit.putString("Order", order);
            toEdit.commit();
        login(username,password, order);
    }

    private void login(final String username, final String password, final String order) {
        class LoginAsync extends AsyncTask<String, Void, String> {
            private Dialog loadingDialog;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loadingDialog = ProgressDialog.show(Login.this, "Please wait ..", "Loading");
            }

            @Override
            protected String doInBackground(String... params) {
                String username = params[0];
                String password = params[1];

                InputStream is= null;
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                nameValuePairs.add(new BasicNameValuePair("username",username));
                nameValuePairs.add(new BasicNameValuePair("password",password));

                if (username.isEmpty() || password.isEmpty()){
                    Toast.makeText(Login.this, "Enter value in all field", Toast.LENGTH_SHORT).show();
                }

                String result = null;
                try {
                    HttpClient httpClient = new DefaultHttpClient();
                    HttpPost httpPost = new HttpPost("http://cerita-aje.esy.es/login.php");
                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    HttpResponse response = httpClient.execute(httpPost);

                    HttpEntity entity= response.getEntity();
                    is= entity.getContent();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"),8);
                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    while ((line= reader.readLine())!=null){
                        sb.append(line+"\n");
                    }
                    result = sb.toString();
                }catch (ClientProtocolException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Log.i(result,"restult ya" +result);
                return result;
            }

            @Override
            protected void onPostExecute(String result) {
                String s = result.trim();
                loadingDialog.dismiss();
                if(s.equalsIgnoreCase("success")){
                    session.createUserLoginSession(username,
                            "Tracking",order);
                    Intent intent = new Intent(Login.this, Start.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    // Add new Flag to start new Activity
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                    intent.putExtra("USERNAME", username);
                    startActivity(intent);
                    finish();
                }else {
                    Toast.makeText(getApplicationContext(),"Invalid username or password",Toast.LENGTH_SHORT).show();
                }
                Log.i(username,"ini user" + username + password+order);
            }
        }
        LoginAsync la = new LoginAsync();
        la.execute(username, password,order);
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Really Exit?")
                .setMessage("Are you sure you want to exit?")
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface arg0, int arg1) {
                        Login.super.onBackPressed();
                    }
                }).create().show();
    }
   /* private void requestJsonObject(){
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, PATH_TO_SERVER, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                GsonBuilder builder = new GsonBuilder();
                Gson mGson = builder.create();
                spinnerData = Arrays.asList(mGson.fromJson(response, DataObject[].class));
                //display first question to the user
                if(null != spinnerData){
                    mSpinner = (Spinner) findViewById(R.id.order_spinner);
                    assert mSpinner != null;
                    mSpinner.setVisibility(View.VISIBLE);
                    SpinnerAdapter spinnerAdapter = new SpinnerAdapter(Login.this, spinnerData);
                    mSpinner.setAdapter(spinnerAdapter);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        queue.add(stringRequest);
    }*/

   /* private void getData(){
        //Creating a string request
        StringRequest stringRequest = new StringRequest(Config.DATA_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject j = null;
                        try {
                            //Parsing the fetched Json String to JSON Object
                            j = new JSONObject(response);

                            //Storing the Array of JSON String to our JSON Array
                            result = j.getJSONArray(Config.JSON_ARRAY);

                            //Calling method getStudents to get the students from the JSON Array
                            getOrders(result);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        //Creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        //Adding request to the queue
        requestQueue.add(stringRequest);
    }
    private void getOrders(JSONArray j){
        //Traversing through all the items in the json array
        for(int i=0;i<j.length();i++){
            try {
                //Getting json object
                JSONObject json = j.getJSONObject(i);

                //Adding the name of the order to array list
                orders.add(json.getString(Config.TAG_ORDER));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        //Setting adapter to show the items in the spinner
        mSpinner.setAdapter(new ArrayAdapter<String>(Login.this, android.R.layout.simple_spinner_dropdown_item, orders));
    }*/
/*
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(
                getApplicationContext(),
                parent.getItemAtPosition(position).toString() + " Selected" ,
                Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }*/
}
