package com.bdg.telkom.fusedlocationtes.baru.belumPakai;

import com.google.gson.annotations.SerializedName;

/**
 * Created by lacorp on 8/12/2016.
 */
public class DataObject {
    @SerializedName("name")
    private String id_order;
    public DataObject(){}
    public DataObject(String id_order) {
        this.id_order = id_order;
    }
    public String getId_order() {
        return id_order;
    }
    public void setId_order(String id_order) {
        this.id_order = id_order;
    }
}
