package com.bdg.telkom.fusedlocationtes.baru.belumPakai;

/**
 * Created by lacorp on 8/11/2016.
 */
public class Config {
    //JSON URL
    public static final String DATA_URL = "http://cerita-aje.esy.es/dataj.php";

    //Tags used in the JSON String
    public static final String TAG_ORDER = "id_order";

    //JSON array name
    public static final String JSON_ARRAY = "result";
}
