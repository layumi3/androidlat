package com.bdg.telkom.fusedlocationtes.baru.belumPakai;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by lacorp on 7/17/2016.
 */
public class SignOut extends AppCompatActivity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*Intent loginIntent = new Intent(getActivity(), Login.class);
        loginIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        getActivity().startActivity(loginIntent);
        finish();*/


    }
}
